import elements from './html-collection.js'
import nodes from './node-list.js'

window.onload = () => {
  elements();
  nodes();
};
